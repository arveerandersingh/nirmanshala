# NIRMANSHALA Setup Guide

## Overview
NIRMANSHALA is an AI-powered architectural rendering application that transforms 3D models and sketches into photorealistic visualizations with realistic lighting, materials, and environments.

## Prerequisites
- Node.js 18+ installed
- Stripe account for payment processing
- Supabase project (already initialized)

## Environment Configuration

### Required Environment Variables
The `.env` file is already configured with:
- `VITE_SUPABASE_URL` - Supabase project URL
- `VITE_SUPABASE_ANON_KEY` - Supabase anonymous key
- `VITE_APP_ID` - Application ID

### Stripe Configuration (Required for Payments)
You need to add Stripe API keys to your Supabase Edge Functions:

1. Get your Stripe API keys from https://dashboard.stripe.com/apikeys
2. Add them to Supabase secrets:
   ```bash
   # Using Supabase CLI (if available)
   supabase secrets set STRIPE_SECRET_KEY=sk_test_...
   supabase secrets set STRIPE_WEBHOOK_SECRET=whsec_...
   ```

3. Or use the Supabase dashboard:
   - Go to Project Settings > Edge Functions
   - Add secrets: `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET`

## Database Setup

### Tables Created
1. **profiles** - User profiles with role management
2. **subscription_plans** - Pricing plans (Free, Monthly, Annual)
3. **user_quotas** - Render quota tracking per user
4. **renders** - Render history and status
5. **orders** - Payment and subscription orders

### Storage Buckets
- **renders** - Stores uploaded and rendered images (10MB max per file)

### Initial Data
The database includes 3 pre-configured subscription plans:
- **Free Plan**: 3 renders per day (₹0)
- **Monthly Plan**: 100 renders per month (₹499)
- **Annual Plan**: Unlimited renders per year (₹10,000)

## User Roles

### Admin Access
The **first user** to register automatically becomes an admin with full access to:
- Admin dashboard (`/admin`)
- User management
- Render history management
- Order management

### Regular Users
All subsequent users have standard access to:
- Render creation (`/render`)
- Gallery (`/gallery`)
- Dashboard (`/dashboard`)
- Pricing and subscription management

## Application Features

### Authentication
- Username/password login (email verification disabled)
- Automatic profile creation on signup
- Protected routes with authentication

### Rendering System
- Drag-and-drop image upload
- Quota tracking and management
- Render history with download capability
- Support for JPG, PNG images (max 10MB)

### Payment Integration
- Stripe checkout for subscriptions
- Automatic quota updates after payment
- Order history tracking
- Payment verification via Edge Functions

### Admin Panel
- View all users and their roles
- Monitor all renders across the platform
- Track all orders and payments
- Comprehensive statistics dashboard

## Edge Functions

### Deployed Functions
1. **create_stripe_checkout** - Creates Stripe payment sessions
2. **verify_stripe_payment** - Verifies payments and updates user quotas

### Function URLs
- Base URL: `https://lomrfymbghfsrcenrxls.supabase.co/functions/v1/`
- Checkout: `create_stripe_checkout`
- Verify: `verify_stripe_payment`

## Running the Application

### Development
```bash
# Install dependencies (if needed)
pnpm install

# Run linting
npm run lint

# The application is deployed automatically
# Access it through your deployment URL
```

### Testing the Application

#### 1. Create First User (Admin)
- Go to `/login`
- Click "Sign Up"
- Enter username, email, password
- This user becomes the admin automatically

#### 2. Test Free Rendering
- Login with your account
- Go to `/render`
- Upload an architectural image
- Click "Start AI Rendering"
- View results in `/gallery`

#### 3. Test Subscription Purchase
- Go to `/pricing`
- Click "Subscribe Now" on Monthly or Annual plan
- Complete Stripe checkout (use test card: 4242 4242 4242 4242)
- Verify quota update in `/dashboard`

#### 4. Test Admin Panel
- Login as the first user (admin)
- Go to `/admin`
- View users, renders, and orders

## Important Notes

### Render Processing
The current implementation uses a **placeholder** for AI rendering. The `simulateRendering` function in `Render.tsx` returns the original image 3 times. 

**To integrate real AI rendering:**
1. Replace the `simulateRendering` function with your AI service API call
2. Update the function to return actual rendered image URLs
3. Consider using services like:
   - Stable Diffusion API
   - Midjourney API
   - Custom AI rendering service

### Quota Management
- Free users: Quota resets daily at midnight UTC
- Monthly users: Quota resets on the same day each month
- Annual users: Unlimited renders (quota = -1)

### Storage Limits
- Individual file size: 10MB maximum
- Bucket: `renders` (public access for viewing)
- File naming: `{user_id}/{timestamp}.{extension}`

### Security
- Row Level Security (RLS) enabled on all tables
- First user automatically gets admin role
- Users can only view/modify their own data
- Admins have full access to all data

## Troubleshooting

### Payment Issues
- Verify Stripe API keys are set in Supabase secrets
- Check Edge Function logs in Supabase dashboard
- Ensure webhook secret is configured correctly

### Upload Issues
- Check file size (must be < 10MB)
- Verify file type (JPG, PNG only)
- Ensure user has remaining quota

### Authentication Issues
- Clear browser cache and cookies
- Check Supabase project status
- Verify environment variables are correct

## Next Steps

1. **Configure Stripe**: Add your Stripe API keys to Supabase secrets
2. **Integrate AI Service**: Replace placeholder rendering with real AI service
3. **Test Complete Flow**: Register → Upload → Render → Purchase → Admin
4. **Customize Branding**: Update colors, logo, and content as needed
5. **Deploy**: The application is ready for production use

## Support

For issues or questions:
- Check Supabase logs for backend errors
- Review browser console for frontend errors
- Verify all environment variables are set correctly
- Ensure Stripe webhooks are configured

## Technology Stack

- **Frontend**: React + TypeScript + Vite
- **UI**: shadcn/ui + Tailwind CSS
- **Backend**: Supabase (PostgreSQL + Edge Functions)
- **Storage**: Supabase Storage
- **Payments**: Stripe
- **Authentication**: Supabase Auth
