import type { ReactNode } from 'react';
import Home from './pages/Home';
import Pricing from './pages/Pricing';
import Render from './pages/Render';
import Gallery from './pages/Gallery';
import Dashboard from './pages/Dashboard';
import Admin from './pages/Admin';
import Login from './pages/Login';
import PaymentSuccess from './pages/PaymentSuccess';
import NotFound from './pages/NotFound';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <Home />,
    visible: true,
  },
  {
    name: 'Pricing',
    path: '/pricing',
    element: <Pricing />,
    visible: true,
  },
  {
    name: 'Render',
    path: '/render',
    element: <Render />,
    visible: true,
  },
  {
    name: 'Gallery',
    path: '/gallery',
    element: <Gallery />,
    visible: true,
  },
  {
    name: 'Dashboard',
    path: '/dashboard',
    element: <Dashboard />,
    visible: false,
  },
  {
    name: 'Admin',
    path: '/admin',
    element: <Admin />,
    visible: false,
  },
  {
    name: 'Login',
    path: '/login',
    element: <Login />,
    visible: false,
  },
  {
    name: 'Payment Success',
    path: '/payment-success',
    element: <PaymentSuccess />,
    visible: false,
  },
  {
    name: 'Not Found',
    path: '*',
    element: <NotFound />,
    visible: false,
  },
];

export default routes;