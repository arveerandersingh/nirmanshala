import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/components/auth/AuthProvider';
import { rendersApi } from '@/db/api';
import type { Render } from '@/types/types';
import { Loader2, Download, Image as ImageIcon } from 'lucide-react';

export default function Gallery() {
  const [renders, setRenders] = useState<Render[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      loadRenders();
    }
  }, [user]);

  const loadRenders = async () => {
    if (!user) return;

    try {
      const data = await rendersApi.getUserRenders(user.id);
      setRenders(data);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load renders',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async (url: string, filename: string) => {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to download image',
        variant: 'destructive',
      });
    }
  };

  const getStatusColor = (status: Render['status']) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500';
      case 'processing':
        return 'bg-blue-500';
      case 'failed':
        return 'bg-red-500';
      default:
        return 'bg-muted';
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-4">Login Required</h2>
              <p className="text-muted-foreground mb-6">Please login to view your gallery</p>
              <Button onClick={() => navigate('/login')} className="w-full">
                Go to Login
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4 text-primary">Your Gallery</h1>
          <p className="text-muted-foreground">View and download your rendered images</p>
        </div>

        {renders.length === 0 ? (
          <Card>
            <CardContent className="py-12">
              <div className="text-center">
                <ImageIcon className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No renders yet</h3>
                <p className="text-muted-foreground mb-6">
                  Start creating stunning architectural renders
                </p>
                <Button onClick={() => navigate('/render')}>
                  Create Your First Render
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {renders.map((render) => (
              <Card key={render.id} className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="relative">
                    <img
                      src={render.original_image_url}
                      alt="Original"
                      className="w-full h-64 object-cover"
                    />
                    <Badge
                      className={`absolute top-4 right-4 ${getStatusColor(render.status)}`}
                    >
                      {render.status}
                    </Badge>
                  </div>
                  
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <p className="text-sm text-muted-foreground">
                          {new Date(render.created_at).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                          })}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Type: {render.render_type}
                        </p>
                      </div>
                    </div>

                    {render.status === 'completed' && render.rendered_images.length > 0 && (
                      <div>
                        <p className="text-sm font-medium mb-2">
                          Rendered Images ({render.rendered_images.length})
                        </p>
                        <div className="grid grid-cols-3 gap-2 mb-4">
                          {render.rendered_images.map((url, index) => (
                            <div key={index} className="relative group">
                              <img
                                src={url}
                                alt={`Render ${index + 1}`}
                                className="w-full h-24 object-cover rounded"
                              />
                              <Button
                                size="sm"
                                variant="secondary"
                                className="absolute inset-0 m-auto w-8 h-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                                onClick={() =>
                                  handleDownload(url, `render-${render.id}-${index + 1}.jpg`)
                                }
                              >
                                <Download className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {render.status === 'failed' && render.error_message && (
                      <p className="text-sm text-destructive">{render.error_message}</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
