import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Zap, Shield, ArrowRight } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen">
      <section className="relative py-20 xl:py-32 px-4 bg-gradient-to-br from-background via-secondary to-background">
        <div className="max-w-6xl mx-auto text-center">
          <Badge className="mb-4 bg-accent text-accent-foreground">AI-Powered Rendering</Badge>
          <h1 className="text-4xl xl:text-6xl font-bold mb-6 text-primary">
            Transform Your Architectural Designs
          </h1>
          <p className="text-lg xl:text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Professional photorealistic rendering powered by AI. Turn your 3D models and sketches
            into stunning visualizations with realistic lighting, materials, and environments.
          </p>
          <div className="flex flex-col xl:flex-row gap-4 justify-center items-center mb-16">
            <Link to="/render">
              <Button size="lg" className="w-full xl:w-auto">
                Start Rendering <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link to="/pricing">
              <Button size="lg" variant="outline" className="w-full xl:w-auto">
                View Pricing
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <Card className="overflow-hidden">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-muted-foreground">BEFORE</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <img
                  src="https://miaoda-conversation-file.s3cdn.medo.dev/user-7pfbjx4mww00/conv-7pfbqhwcqpkw/20251121/file-7pfxgppg9a80.jpg"
                  alt="3D architectural sketch before rendering"
                  className="w-full h-80 object-cover"
                />
                <div className="p-4 bg-muted/50">
                  <p className="text-sm text-muted-foreground">Basic 3D Model</p>
                </div>
              </CardContent>
            </Card>

            <Card className="overflow-hidden border-2 border-accent">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-accent flex items-center gap-2">
                  <Sparkles className="h-4 w-4" />
                  AFTER - AI RENDERED
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <img
                  src="https://miaoda-conversation-file.s3cdn.medo.dev/user-7pfbjx4mww00/conv-7pfbqhwcqpkw/20251121/file-7pfxljc66gow.jpg"
                  alt="Photorealistic AI rendered architectural visualization"
                  className="w-full h-80 object-cover"
                />
                <div className="p-4 bg-accent/10">
                  <p className="text-sm font-medium">Photorealistic Rendering</p>
                  <p className="text-xs text-muted-foreground">
                    With realistic lighting, materials & environment
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-8 flex items-center justify-center gap-2 text-muted-foreground">
            <ArrowRight className="h-4 w-4" />
            <span className="text-sm">
              Transform your designs in minutes with professional-grade AI rendering
            </span>
          </div>
        </div>
      </section>

      <section className="py-16 xl:py-24 px-4 bg-background">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl xl:text-4xl font-bold mb-4 text-primary">Why Choose NIRMANSHALA?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Professional-grade rendering tools designed for architects and design professionals
            </p>
          </div>
          
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
            <Card className="border-2 hover:border-accent transition-colors">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4">
                  <Sparkles className="h-6 w-6 text-accent" />
                </div>
                <CardTitle>AI-Powered Quality</CardTitle>
                <CardDescription>
                  Advanced AI algorithms deliver professional-grade renders with stunning detail and realism
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-2 hover:border-accent transition-colors">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4">
                  <Zap className="h-6 w-6 text-accent" />
                </div>
                <CardTitle>Lightning Fast</CardTitle>
                <CardDescription>
                  Generate multiple high-quality renders in seconds, not hours. Perfect for tight deadlines
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-2 hover:border-accent transition-colors">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4">
                  <Shield className="h-6 w-6 text-accent" />
                </div>
                <CardTitle>Flexible Plans</CardTitle>
                <CardDescription>
                  From free daily renders to unlimited annual plans. Choose what works best for your workflow
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16 xl:py-24 px-4 bg-secondary">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl xl:text-4xl font-bold mb-4 text-primary">Simple Pricing</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Choose the plan that fits your needs
            </p>
          </div>
          
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Free</CardTitle>
                <CardDescription>Perfect for trying out</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold">₹0</span>
                  <span className="text-muted-foreground">/day</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center">
                    <span className="mr-2">✓</span> 3 renders per day
                  </li>
                  <li className="flex items-center">
                    <span className="mr-2">✓</span> Basic quality
                  </li>
                  <li className="flex items-center">
                    <span className="mr-2">✓</span> Standard processing
                  </li>
                </ul>
                <Link to="/render">
                  <Button variant="outline" className="w-full">Get Started</Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="border-2 border-accent">
              <CardHeader>
                <Badge className="w-fit mb-2 bg-accent text-accent-foreground">Popular</Badge>
                <CardTitle>Monthly</CardTitle>
                <CardDescription>For regular users</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold">₹499</span>
                  <span className="text-muted-foreground">/month</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center">
                    <span className="mr-2">✓</span> 100 renders per month
                  </li>
                  <li className="flex items-center">
                    <span className="mr-2">✓</span> High quality
                  </li>
                  <li className="flex items-center">
                    <span className="mr-2">✓</span> Priority processing
                  </li>
                  <li className="flex items-center">
                    <span className="mr-2">✓</span> Download originals
                  </li>
                </ul>
                <Link to="/pricing">
                  <Button className="w-full">Subscribe Now</Button>
                </Link>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Annual</CardTitle>
                <CardDescription>Best value for professionals</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold">₹10,000</span>
                  <span className="text-muted-foreground">/year</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center">
                    <span className="mr-2">✓</span> Unlimited renders
                  </li>
                  <li className="flex items-center">
                    <span className="mr-2">✓</span> Highest quality
                  </li>
                  <li className="flex items-center">
                    <span className="mr-2">✓</span> Priority processing
                  </li>
                  <li className="flex items-center">
                    <span className="mr-2">✓</span> Download originals
                  </li>
                  <li className="flex items-center">
                    <span className="mr-2">✓</span> Advanced features
                  </li>
                </ul>
                <Link to="/pricing">
                  <Button className="w-full">Subscribe Now</Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16 xl:py-24 px-4 bg-background">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl xl:text-4xl font-bold mb-6 text-primary">
            Ready to Transform Your Designs?
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Join thousands of architects and designers using NIRMANSHALA
          </p>
          <Link to="/render">
            <Button size="lg">
              Start Rendering Now <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
