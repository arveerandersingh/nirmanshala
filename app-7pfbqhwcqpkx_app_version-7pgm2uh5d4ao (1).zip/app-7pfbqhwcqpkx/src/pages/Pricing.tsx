import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/components/auth/AuthProvider';
import { plansApi } from '@/db/api';
import { supabase } from '@/db/supabase';
import type { SubscriptionPlan } from '@/types/types';
import { Loader2, Check } from 'lucide-react';

export default function Pricing() {
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState<string | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    loadPlans();
  }, []);

  const loadPlans = async () => {
    try {
      const data = await plansApi.getAllPlans();
      setPlans(data);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load pricing plans',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePurchase = async (plan: SubscriptionPlan) => {
    if (!user) {
      navigate('/login', { state: { from: '/pricing' } });
      return;
    }

    if (plan.name === 'free') {
      toast({
        title: 'Info',
        description: 'You are already on the free plan',
      });
      return;
    }

    setPurchasing(plan.id);

    try {
      const { data, error } = await supabase.functions.invoke('create_stripe_checkout', {
        body: JSON.stringify({
          plan_id: plan.id,
          items: [
            {
              name: plan.display_name,
              price: plan.price,
              quantity: 1,
            },
          ],
          currency: plan.currency.toLowerCase(),
        }),
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || 'Failed to create checkout session');
      }

      if (data?.url) {
        window.open(data.url, '_blank');
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to initiate payment',
        variant: 'destructive',
      });
    } finally {
      setPurchasing(null);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 xl:py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl xl:text-5xl font-bold mb-4 text-primary">Choose Your Plan</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Select the perfect plan for your architectural rendering needs
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          {plans.map((plan) => {
            const features = Array.isArray(plan.features) ? plan.features : [];
            const isPopular = plan.name === 'monthly';
            const isFree = plan.name === 'free';

            return (
              <Card
                key={plan.id}
                className={isPopular ? 'border-2 border-accent shadow-lg' : ''}
              >
                <CardHeader>
                  {isPopular && (
                    <Badge className="w-fit mb-2 bg-accent text-accent-foreground">
                      Most Popular
                    </Badge>
                  )}
                  <CardTitle className="text-2xl">{plan.display_name}</CardTitle>
                  <CardDescription>
                    {isFree && 'Perfect for trying out'}
                    {plan.name === 'monthly' && 'For regular users'}
                    {plan.name === 'annual' && 'Best value for professionals'}
                  </CardDescription>
                  <div className="mt-4">
                    <span className="text-4xl font-bold">
                      {plan.currency === 'INR' ? '₹' : '$'}
                      {plan.price.toLocaleString()}
                    </span>
                    <span className="text-muted-foreground">
                      /{plan.quota_period === 'daily' ? 'day' : plan.quota_period === 'monthly' ? 'month' : 'year'}
                    </span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <Check className="h-5 w-5 text-accent mr-2 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button
                    className="w-full"
                    variant={isPopular ? 'default' : 'outline'}
                    onClick={() => handlePurchase(plan)}
                    disabled={purchasing === plan.id || isFree}
                  >
                    {purchasing === plan.id ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : isFree ? (
                      'Current Plan'
                    ) : (
                      'Subscribe Now'
                    )}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-12 text-center text-sm text-muted-foreground">
          <p>All plans include secure payment processing via Stripe</p>
          <p className="mt-2">Need help choosing? Contact our support team</p>
        </div>
      </div>
    </div>
  );
}
