import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/components/auth/AuthProvider';
import { quotasApi, rendersApi } from '@/db/api';
import { supabase } from '@/db/supabase';
import type { UserQuotaWithPlan } from '@/types/types';
import { Upload, Loader2, Image as ImageIcon, Sparkles } from 'lucide-react';

export default function Render() {
  const [quota, setQuota] = useState<UserQuotaWithPlan | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [rendering, setRendering] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      loadQuota();
    }
  }, [user]);

  const loadQuota = async () => {
    if (!user) return;
    
    try {
      const data = await quotasApi.getUserQuota(user.id);
      setQuota(data);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load quota information',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelect = (file: File) => {
    if (!file.type.startsWith('image/')) {
      toast({
        title: 'Error',
        description: 'Please select an image file',
        variant: 'destructive',
      });
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: 'Error',
        description: 'File size must be less than 10MB',
        variant: 'destructive',
      });
      return;
    }

    setSelectedFile(file);
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreviewUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelect(e.target.files[0]);
    }
  };

  const simulateRendering = async (originalUrl: string): Promise<string[]> => {
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    return [
      originalUrl,
      originalUrl,
      originalUrl,
    ];
  };

  const handleRender = async () => {
    if (!user) {
      navigate('/login', { state: { from: '/render' } });
      return;
    }

    if (!selectedFile) {
      toast({
        title: 'Error',
        description: 'Please select an image first',
        variant: 'destructive',
      });
      return;
    }

    if (quota && quota.renders_remaining === 0) {
      toast({
        title: 'Quota Exhausted',
        description: 'Please upgrade your plan to continue rendering',
        variant: 'destructive',
      });
      navigate('/pricing');
      return;
    }

    setUploading(true);

    try {
      const quotaCheck = await quotasApi.checkAndUseQuota(user.id);
      
      if (!quotaCheck.success) {
        throw new Error(quotaCheck.error || 'Quota check failed');
      }

      const fileExt = selectedFile.name.split('.').pop();
      const fileName = `${user.id}/${Date.now()}.${fileExt}`;
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('renders')
        .upload(fileName, selectedFile);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('renders')
        .getPublicUrl(uploadData.path);

      const render = await rendersApi.createRender(user.id, publicUrl);
      
      if (!render) throw new Error('Failed to create render record');

      setUploading(false);
      setRendering(true);

      const renderedImages = await simulateRendering(publicUrl);

      await rendersApi.updateRenderStatus(render.id, 'completed', renderedImages);

      toast({
        title: 'Success',
        description: 'Your render is complete!',
      });

      await loadQuota();
      navigate('/gallery');
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Rendering failed',
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
      setRendering(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardHeader>
            <CardTitle>Login Required</CardTitle>
            <CardDescription>Please login to start rendering</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate('/login')} className="w-full">
              Go to Login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const rendersRemaining = quota?.renders_remaining ?? 0;
  const rendersUsed = quota?.renders_used ?? 0;
  const totalQuota = quota?.plan?.render_quota ?? 3;
  const isUnlimited = totalQuota === -1;

  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 text-primary">AI Rendering Studio</h1>
          <p className="text-muted-foreground mb-2">
            Upload your architectural design and transform it into photorealistic visualization
          </p>
          <p className="text-sm text-muted-foreground">
            Our AI adds realistic lighting, materials, environment, and context to your 3D models
          </p>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Your Quota</CardTitle>
            <CardDescription>
              {isUnlimited ? (
                'Unlimited renders available'
              ) : (
                `${rendersRemaining} of ${totalQuota} renders remaining`
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!isUnlimited && (
              <Progress value={(rendersUsed / totalQuota) * 100} className="mb-2" />
            )}
            <p className="text-sm text-muted-foreground">
              Plan: {quota?.plan?.display_name || 'Free'}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Upload Image</CardTitle>
            <CardDescription>
              Upload your 3D model, sketch, or architectural drawing (JPG, PNG - Max 10MB)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                dragActive ? 'border-accent bg-accent/10' : 'border-border'
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              {previewUrl ? (
                <div className="space-y-4">
                  <img
                    src={previewUrl}
                    alt="Preview"
                    className="max-h-96 mx-auto rounded-lg"
                  />
                  <div className="flex gap-4 justify-center">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSelectedFile(null);
                        setPreviewUrl(null);
                      }}
                    >
                      Remove
                    </Button>
                    <Button
                      onClick={handleRender}
                      disabled={uploading || rendering}
                    >
                      {uploading || rendering ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          {uploading ? 'Uploading...' : 'Rendering...'}
                        </>
                      ) : (
                        <>
                          <Sparkles className="mr-2 h-4 w-4" />
                          Start AI Rendering
                        </>
                      )}
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    AI will add photorealistic lighting, materials, and environment
                  </p>
                </div>
              ) : (
                <label className="cursor-pointer">
                  <input
                    type="file"
                    className="hidden"
                    accept="image/*"
                    onChange={handleFileInput}
                  />
                  <div className="flex flex-col items-center">
                    <Upload className="h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-lg font-medium mb-2">
                      Drop your image here or click to browse
                    </p>
                    <p className="text-sm text-muted-foreground mb-4">
                      Supports JPG, PNG (Max 10MB)
                    </p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Sparkles className="h-3 w-3" />
                      <span>AI will enhance with realistic lighting & materials</span>
                    </div>
                  </div>
                </label>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
