import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/components/auth/AuthProvider';
import { quotasApi, ordersApi } from '@/db/api';
import type { UserQuotaWithPlan, Order } from '@/types/types';
import { Loader2, Sparkles, CreditCard, Calendar } from 'lucide-react';

export default function Dashboard() {
  const [quota, setQuota] = useState<UserQuotaWithPlan | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    if (!user) return;

    try {
      const [quotaData, ordersData] = await Promise.all([
        quotasApi.getUserQuota(user.id),
        ordersApi.getUserOrders(user.id),
      ]);
      setQuota(quotaData);
      setOrders(ordersData);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load dashboard data',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-4">Login Required</h2>
              <p className="text-muted-foreground mb-6">Please login to view your dashboard</p>
              <Button onClick={() => navigate('/login')} className="w-full">
                Go to Login
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const rendersRemaining = quota?.renders_remaining ?? 0;
  const rendersUsed = quota?.renders_used ?? 0;
  const totalQuota = quota?.plan?.render_quota ?? 3;
  const isUnlimited = totalQuota === -1;

  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2 text-primary">Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome back, {profile?.full_name || profile?.username || 'User'}!
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Current Plan</CardTitle>
              <Sparkles className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{quota?.plan?.display_name || 'Free'}</div>
              <p className="text-xs text-muted-foreground">
                {quota?.plan?.currency === 'INR' ? '₹' : '$'}
                {quota?.plan?.price || 0}/{quota?.plan?.quota_period || 'day'}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Renders Remaining</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isUnlimited ? '∞' : rendersRemaining}
              </div>
              <p className="text-xs text-muted-foreground">
                {isUnlimited ? 'Unlimited' : `${rendersUsed} used of ${totalQuota}`}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Period Ends</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {quota?.period_end
                  ? new Date(quota.period_end).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                    })
                  : 'N/A'}
              </div>
              <p className="text-xs text-muted-foreground">
                {quota?.period_end
                  ? `${Math.ceil(
                      (new Date(quota.period_end).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
                    )} days left`
                  : 'No active period'}
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Quota Usage</CardTitle>
            <CardDescription>
              {isUnlimited
                ? 'You have unlimited renders'
                : `${rendersRemaining} renders remaining in current period`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!isUnlimited && (
              <>
                <Progress value={(rendersUsed / totalQuota) * 100} className="mb-4" />
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>{rendersUsed} used</span>
                  <span>{rendersRemaining} remaining</span>
                </div>
              </>
            )}
            <div className="mt-6 flex gap-4">
              <Button onClick={() => navigate('/render')}>
                <Sparkles className="mr-2 h-4 w-4" />
                Start Rendering
              </Button>
              {!isUnlimited && (
                <Button variant="outline" onClick={() => navigate('/pricing')}>
                  Upgrade Plan
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Order History</CardTitle>
            <CardDescription>Your recent purchases and subscriptions</CardDescription>
          </CardHeader>
          <CardContent>
            {orders.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-4">No orders yet</p>
                <Button variant="outline" onClick={() => navigate('/pricing')}>
                  View Plans
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {orders.map((order) => (
                  <div
                    key={order.id}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div>
                      <p className="font-medium">
                        {Array.isArray(order.items) && order.items[0]?.name}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(order.created_at).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                        })}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">
                        {order.currency === 'INR' ? '₹' : '$'}
                        {order.total_amount.toLocaleString()}
                      </p>
                      <Badge
                        variant={
                          order.status === 'completed'
                            ? 'default'
                            : order.status === 'pending'
                              ? 'secondary'
                              : 'destructive'
                        }
                      >
                        {order.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
