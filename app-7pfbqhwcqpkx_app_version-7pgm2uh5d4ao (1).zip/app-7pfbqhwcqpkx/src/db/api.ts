import { supabase } from './supabase';
import type {
  Profile,
  SubscriptionPlan,
  UserQuota,
  Render,
  Order,
  QuotaCheckResult,
  UserQuotaWithPlan,
} from '@/types/types';

export const profilesApi = {
  async getProfile(userId: string): Promise<Profile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async updateProfile(userId: string, updates: Partial<Profile>): Promise<Profile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', userId)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async getAllProfiles(): Promise<Profile[]> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },
};

export const plansApi = {
  async getAllPlans(): Promise<SubscriptionPlan[]> {
    const { data, error } = await supabase
      .from('subscription_plans')
      .select('*')
      .eq('is_active', true)
      .order('price', { ascending: true });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getPlanById(planId: string): Promise<SubscriptionPlan | null> {
    const { data, error } = await supabase
      .from('subscription_plans')
      .select('*')
      .eq('id', planId)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async getPlanByName(name: string): Promise<SubscriptionPlan | null> {
    const { data, error } = await supabase
      .from('subscription_plans')
      .select('*')
      .eq('name', name)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },
};

export const quotasApi = {
  async getUserQuota(userId: string): Promise<UserQuotaWithPlan | null> {
    const { data, error } = await supabase
      .from('user_quotas')
      .select('*, plan:subscription_plans(*)')
      .eq('user_id', userId)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async checkAndUseQuota(userId: string): Promise<QuotaCheckResult> {
    const { data, error } = await supabase.rpc('check_and_use_render_quota', {
      p_user_id: userId,
    });
    
    if (error) throw error;
    return data as QuotaCheckResult;
  },

  async updateUserPlan(userId: string, planId: string): Promise<void> {
    const plan = await plansApi.getPlanById(planId);
    if (!plan) throw new Error('Plan not found');

    const periodEnd = new Date();
    if (plan.quota_period === 'daily') {
      periodEnd.setDate(periodEnd.getDate() + 1);
    } else if (plan.quota_period === 'monthly') {
      periodEnd.setMonth(periodEnd.getMonth() + 1);
    } else if (plan.quota_period === 'yearly') {
      periodEnd.setFullYear(periodEnd.getFullYear() + 1);
    }

    const { error } = await supabase
      .from('user_quotas')
      .update({
        plan_id: planId,
        renders_used: 0,
        renders_remaining: plan.render_quota,
        period_start: new Date().toISOString(),
        period_end: periodEnd.toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq('user_id', userId);
    
    if (error) throw error;
  },
};

export const rendersApi = {
  async createRender(userId: string, originalImageUrl: string, renderType = 'architectural'): Promise<Render | null> {
    const { data, error } = await supabase
      .from('renders')
      .insert({
        user_id: userId,
        original_image_url: originalImageUrl,
        render_type: renderType,
        status: 'pending',
      })
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async getUserRenders(userId: string, limit = 50): Promise<Render[]> {
    const { data, error } = await supabase
      .from('renders')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getAllRenders(limit = 100): Promise<Render[]> {
    const { data, error } = await supabase
      .from('renders')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async updateRenderStatus(
    renderId: string,
    status: Render['status'],
    renderedImages?: string[],
    errorMessage?: string
  ): Promise<Render | null> {
    const updates: Partial<Render> = { status };
    
    if (renderedImages) {
      updates.rendered_images = renderedImages;
    }
    if (errorMessage) {
      updates.error_message = errorMessage;
    }
    if (status === 'completed' || status === 'failed') {
      updates.completed_at = new Date().toISOString();
    }

    const { data, error } = await supabase
      .from('renders')
      .update(updates)
      .eq('id', renderId)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },
};

export const ordersApi = {
  async getUserOrders(userId: string): Promise<Order[]> {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getOrderBySessionId(sessionId: string): Promise<Order | null> {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('stripe_session_id', sessionId)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async getAllOrders(limit = 100): Promise<Order[]> {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },
};
