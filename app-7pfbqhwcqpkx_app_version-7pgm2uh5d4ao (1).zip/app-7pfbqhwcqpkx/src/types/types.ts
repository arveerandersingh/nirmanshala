export type UserRole = 'user' | 'admin';

export interface Profile {
  id: string;
  email: string | null;
  username: string | null;
  full_name: string | null;
  role: UserRole;
  created_at: string;
  updated_at: string;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  display_name: string;
  price: number;
  currency: string;
  render_quota: number;
  quota_period: 'daily' | 'monthly' | 'yearly';
  stripe_price_id: string | null;
  features: string[];
  is_active: boolean;
  created_at: string;
}

export interface UserQuota {
  id: string;
  user_id: string;
  plan_id: string;
  renders_used: number;
  renders_remaining: number;
  period_start: string;
  period_end: string;
  created_at: string;
  updated_at: string;
}

export type RenderStatus = 'pending' | 'processing' | 'completed' | 'failed';

export interface Render {
  id: string;
  user_id: string;
  original_image_url: string;
  rendered_images: string[];
  status: RenderStatus;
  render_type: string;
  metadata: Record<string, unknown>;
  error_message: string | null;
  created_at: string;
  completed_at: string | null;
}

export type OrderStatus = 'pending' | 'completed' | 'cancelled' | 'refunded';

export interface Order {
  id: string;
  user_id: string | null;
  plan_id: string | null;
  items: OrderItem[];
  total_amount: number;
  currency: string;
  status: OrderStatus;
  stripe_session_id: string | null;
  stripe_payment_intent_id: string | null;
  customer_email: string | null;
  customer_name: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface OrderItem {
  name: string;
  price: number;
  quantity: number;
  image_url?: string;
}

export interface QuotaCheckResult {
  success: boolean;
  renders_remaining?: number;
  error?: string;
}

export interface UserQuotaWithPlan extends UserQuota {
  plan?: SubscriptionPlan;
}
