/*
# Create Renders and Orders Tables

## 1. New Tables
- `renders`
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `original_image_url` (text) - URL of uploaded image
  - `rendered_images` (jsonb) - Array of rendered image URLs
  - `status` (render_status enum) - 'pending', 'processing', 'completed', 'failed'
  - `render_type` (text) - Type of rendering (e.g., 'architectural', 'detail')
  - `metadata` (jsonb) - Additional render metadata
  - `error_message` (text) - Error message if failed
  - `created_at` (timestamptz)
  - `completed_at` (timestamptz)

- `orders`
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `plan_id` (uuid, references subscription_plans)
  - `items` (jsonb) - Order items details
  - `total_amount` (numeric) - Total order amount
  - `currency` (text) - Currency code
  - `status` (order_status enum) - 'pending', 'completed', 'cancelled', 'refunded'
  - `stripe_session_id` (text, unique)
  - `stripe_payment_intent_id` (text)
  - `customer_email` (text)
  - `customer_name` (text)
  - `completed_at` (timestamptz)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

## 2. Security
- Users can view their own renders and orders
- Admins can view all renders and orders
- Only service role can create/update orders (via Edge Functions)
- Users can create renders (with quota check)

## 3. Indexes
- Index on user_id for faster lookups
- Index on status for filtering
- Index on stripe_session_id for payment verification
*/

CREATE TYPE render_status AS ENUM ('pending', 'processing', 'completed', 'failed');
CREATE TYPE order_status AS ENUM ('pending', 'completed', 'cancelled', 'refunded');

CREATE TABLE IF NOT EXISTS renders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  original_image_url text NOT NULL,
  rendered_images jsonb DEFAULT '[]'::jsonb,
  status render_status DEFAULT 'pending'::render_status NOT NULL,
  render_type text DEFAULT 'architectural',
  metadata jsonb DEFAULT '{}'::jsonb,
  error_message text,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  plan_id uuid REFERENCES subscription_plans(id),
  items jsonb NOT NULL,
  total_amount numeric(12,2) NOT NULL,
  currency text NOT NULL DEFAULT 'INR',
  status order_status NOT NULL DEFAULT 'pending'::order_status,
  stripe_session_id text UNIQUE,
  stripe_payment_intent_id text,
  customer_email text,
  customer_name text,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_renders_user_id ON renders(user_id);
CREATE INDEX idx_renders_status ON renders(status);
CREATE INDEX idx_renders_created_at ON renders(created_at DESC);

CREATE INDEX idx_orders_user_id ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_stripe_session_id ON orders(stripe_session_id);
CREATE INDEX idx_orders_created_at ON orders(created_at DESC);

ALTER TABLE renders ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own renders" ON renders
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create renders" ON renders
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all renders" ON renders
  FOR SELECT USING (is_admin(auth.uid()));

CREATE POLICY "Admins can manage all renders" ON renders
  FOR ALL USING (is_admin(auth.uid()));

CREATE POLICY "Users can view own orders" ON orders
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all orders" ON orders
  FOR SELECT USING (is_admin(auth.uid()));

CREATE POLICY "Service role can manage orders" ON orders
  FOR ALL USING (auth.jwt()->>'role' = 'service_role');