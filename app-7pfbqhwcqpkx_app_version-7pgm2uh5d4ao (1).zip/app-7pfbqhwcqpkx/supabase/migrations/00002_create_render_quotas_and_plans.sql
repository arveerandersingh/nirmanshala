/*
# Create Render Quotas and Subscription Plans

## 1. New Tables
- `subscription_plans`
  - `id` (uuid, primary key)
  - `name` (text, unique) - Plan name (e.g., 'free', 'monthly', 'annual')
  - `display_name` (text) - Display name for UI
  - `price` (numeric) - Price in INR
  - `currency` (text) - Currency code (default: 'INR')
  - `render_quota` (integer) - Number of renders (-1 for unlimited)
  - `quota_period` (text) - 'daily', 'monthly', 'yearly'
  - `stripe_price_id` (text) - Stripe price ID for payment
  - `features` (jsonb) - Additional features as JSON
  - `is_active` (boolean) - Whether plan is available
  - `created_at` (timestamptz)

- `user_quotas`
  - `id` (uuid, primary key)
  - `user_id` (uuid, references profiles)
  - `plan_id` (uuid, references subscription_plans)
  - `renders_used` (integer) - Renders used in current period
  - `renders_remaining` (integer) - Renders remaining
  - `period_start` (timestamptz) - Start of current quota period
  - `period_end` (timestamptz) - End of current quota period
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

## 2. Security
- Public read access to subscription_plans
- Users can view their own quotas
- Admins can manage all quotas
- RPC function to check and decrement quota

## 3. Initial Data
- Insert three subscription plans: Free (3/day), Monthly (100/month), Annual (unlimited/year)
*/

CREATE TABLE IF NOT EXISTS subscription_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  display_name text NOT NULL,
  price numeric(10,2) NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'INR',
  render_quota integer NOT NULL,
  quota_period text NOT NULL CHECK (quota_period IN ('daily', 'monthly', 'yearly')),
  stripe_price_id text,
  features jsonb DEFAULT '[]'::jsonb,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_quotas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE UNIQUE NOT NULL,
  plan_id uuid REFERENCES subscription_plans(id) NOT NULL,
  renders_used integer DEFAULT 0 NOT NULL,
  renders_remaining integer NOT NULL,
  period_start timestamptz DEFAULT now() NOT NULL,
  period_end timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE subscription_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_quotas ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active plans" ON subscription_plans
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage plans" ON subscription_plans
  FOR ALL USING (is_admin(auth.uid()));

CREATE POLICY "Users can view own quota" ON user_quotas
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all quotas" ON user_quotas
  FOR ALL USING (is_admin(auth.uid()));

INSERT INTO subscription_plans (name, display_name, price, render_quota, quota_period, features) VALUES
  ('free', 'Daily Free Plan', 0, 3, 'daily', '["3 renders per day", "Basic quality", "Standard processing"]'::jsonb),
  ('monthly', 'Monthly Plan', 499, 100, 'monthly', '["100 renders per month", "High quality", "Priority processing", "Download originals"]'::jsonb),
  ('annual', 'Annual Plan', 10000, -1, 'yearly', '["Unlimited renders", "Highest quality", "Priority processing", "Download originals", "Advanced features"]'::jsonb);

CREATE OR REPLACE FUNCTION check_and_use_render_quota(p_user_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_quota user_quotas;
  v_plan subscription_plans;
  v_result jsonb;
BEGIN
  SELECT * INTO v_quota FROM user_quotas WHERE user_id = p_user_id FOR UPDATE;
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'No quota found for user');
  END IF;
  
  IF v_quota.period_end < now() THEN
    SELECT * INTO v_plan FROM subscription_plans WHERE id = v_quota.plan_id;
    
    UPDATE user_quotas SET
      renders_used = 0,
      renders_remaining = CASE WHEN v_plan.render_quota = -1 THEN -1 ELSE v_plan.render_quota END,
      period_start = now(),
      period_end = CASE 
        WHEN v_plan.quota_period = 'daily' THEN now() + interval '1 day'
        WHEN v_plan.quota_period = 'monthly' THEN now() + interval '1 month'
        WHEN v_plan.quota_period = 'yearly' THEN now() + interval '1 year'
      END,
      updated_at = now()
    WHERE user_id = p_user_id
    RETURNING * INTO v_quota;
  END IF;
  
  IF v_quota.renders_remaining = 0 THEN
    RETURN jsonb_build_object('success', false, 'error', 'Quota exhausted');
  END IF;
  
  UPDATE user_quotas SET
    renders_used = renders_used + 1,
    renders_remaining = CASE WHEN renders_remaining = -1 THEN -1 ELSE renders_remaining - 1 END,
    updated_at = now()
  WHERE user_id = p_user_id;
  
  RETURN jsonb_build_object('success', true, 'renders_remaining', CASE WHEN v_quota.renders_remaining = -1 THEN -1 ELSE v_quota.renders_remaining - 1 END);
END;
$$;

CREATE OR REPLACE FUNCTION initialize_user_quota()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_free_plan_id uuid;
BEGIN
  SELECT id INTO v_free_plan_id FROM subscription_plans WHERE name = 'free' LIMIT 1;
  
  INSERT INTO user_quotas (user_id, plan_id, renders_used, renders_remaining, period_start, period_end)
  VALUES (
    NEW.id,
    v_free_plan_id,
    0,
    3,
    now(),
    now() + interval '1 day'
  );
  
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_profile_created ON profiles;
CREATE TRIGGER on_profile_created
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION initialize_user_quota();