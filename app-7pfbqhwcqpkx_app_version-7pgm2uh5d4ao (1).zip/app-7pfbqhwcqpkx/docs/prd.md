# NIRMANSHALA Requirements Document

## 1. Application Overview

### 1.1 Application Name
NIRMANSHALA
\n### 1.2 Application Description
An AI-powered image rendering application for architectural and design visualization, providing professional rendering services with flexible pricing plans.

### 1.3 Reference Link
https://app.myarchitectai.com/

## 2. Core Features

### 2.1 AI Image Rendering
- Users can upload images for AI-powered rendering
- System generates 3 rendered images per day for free users
- Support for architectural design and detail rendering

### 2.2 Pricing Plans
- **Daily Free Plan**: 3 renders per day
- **Monthly Plan**: ₹499 for 100 renders per month
- **Annual Plan**: ₹10,000 for unlimited renders per year
\n### 2.3 Payment Integration
- Payment method: Google Pay (GPay)
- Payment account: 8871136107
\n### 2.4 User Account System
- User registration and login
- Render quota tracking and management
- Rendering history and download records

## 3. Design Style

### 3.1 Color Scheme
- Primary color: Deep blue (#2C3E50) representing professionalism and technology
- Secondary color: Bright orange (#E67E22) for call-to-action buttons and highlights
- Background: Clean white (#FFFFFF) with light gray (#F5F5F5) sections

### 3.2 Visual Details
- Rounded corners with8px radius for cards and buttons
- Subtle shadow effects (02px 8px rgba(0,0,0,0.1)) for depth
- Modern flat icon style with consistent line weight
- Smooth transitions (0.3s ease) for interactive elements

### 3.3 Layout Structure
- Card-based layout for rendering results display
- Grid system for image gallery presentation
- Fixed top navigation bar with clear pricing and account access
- Centered upload area with drag-and-drop functionality